/**
 * 开发环境
 */
;(function () {
  window.SITE_CONFIG = {}
  // api接口请求地址
  window.SITE_CONFIG['baseUrl'] = 'http://localhost:8080/dbblog/'
  // window.SITE_CONFIG['baseUrl'] = 'http://182.254.171.61:8080/dbblog/'
})()
