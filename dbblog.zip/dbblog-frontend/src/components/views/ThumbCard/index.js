import ThumbCard from './ThumbCard.vue'
export default ThumbCard
