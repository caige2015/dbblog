/**
 * 生产环境
 */
;(function () {
  window.SITE_CONFIG = {}
  // api接口请求地址
  window.SITE_CONFIG['baseUrl'] = 'http://47.95.122.126:8080/dbblog'
})()
